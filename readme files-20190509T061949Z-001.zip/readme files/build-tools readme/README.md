# menlo-core

in root directory, run this to get started:

`npm ci`

##


## build and deploy menlo apps to the bench
###### If you still wish to use the old interface just use -v to switch between versions



To automate your build and deployment environment use:
`node build.js`

To see a list of options use:

`node build.js -h` which will display something similar to the following:

#### Main Options: build :pick: or deploy :rocket:
###### (use only one of these)
```
-B, --build                         This only builds what apps you specify

-D, --deploy                        This only deploys what apps you specify

-A, --build-and-deploy              This builds and deploys what you specify

-E, --build-and-deploy-everything   This builds and deploys everything

-X, --deploy-all-existing           This deploys all existing pre-built packages
```

#### Target Apps: target the apps you want :dart:
###### (as many as you want)
```
-e, --everything                    specifies that whatever the script does it
                                    will do to everything

-s, --center-stack                  target center-stack for your build or
                                    deployment

-p, --phone                         target phone app for your build or
                                    deployment

-m, --media                         target media app for your build or
                                    deployment

-r, --radio                         target radio app for your build or
                                    deployment

-a, --applink                       target applink for your build or deployment

-t, --themes                        target themes for your build or deployment
```

####  Optimize Builds: save time :watch:
###### (If you didn't make changes to common, internal, or dependencies [between builds], you should utilize these)
```
-M, --no-common                     If you dont need a fresh build of common,
                                    add this

-I, --no-internal                   If you dont need a fresh build of
                                    menlo-internal, add this

-N, --no-ci                         This will skip all npm ci's on your apps.
                                    Try to use if possible if you dont want to
                                    ci your apps again.
 
-K, --no-sdk                        This will skip re-bulding menlo-sdk. Use
                                    this option to optimze you build.

```
#### Clean Environment: clean your environment :shower:
```
-c, --clean                         This cleans all build output folders.

-C, --clean-more                    This will clean all build output folders,
                                    node_modules, and npm cache.

```
#### Info: see more info during your build :microscope:
```
-s, --silent                        silence npm output (default is verbose)

-g, --debug                         if you want to debug the script
```

#### Change Versions: Switch between v1 and v2 :clock10:
```
-v, --switch-version                use this flag to switch between v1 and v2
```

#### Help: Show the help menu :question::exclamation:
```
-h --help                           output usage information
```
##
## notes:

#### **Main Options (pick only :one: of them during each run)**
  - **Broad use cases**
    - **Some options make use of all the apps**
      - **For example:**
        - ```node build.js --build-and-deploy-everything```

        - ```node build.js --build --everything```

        - ```node build.js --deploy --everything```

        - ```node build.js --deploy-all-existing```

  - **Specific use cases**
    - **Others require app targets, to only act upon the apps that you wish to build or deploy**

      - **For example:**  
        - ```node build.js --build-and-deploy --center-stack --phone --media --radio```

        - ```node build.js --build --center-stack --phone --media --radio```

        - ```node build.js --deploy --center-stack --phone --media --radio```

#### Optimizations
- ##### **Developers**
  - You most likely have already pulled in all of your dependencies off the web for your app

    - **If that is the case, then you probably do NOT want to run "npm ci" again on any of your applications**
      - You can add `--no-ci` to bypass the default behavior which will automatically ci everything you build. You **DEFINITELY SHOULD USE THIS OPTION**

  - You probably also do not want to rebuild your menlo-common library or menlo-internal library each time you run the script

    - **SAVE A LOT OF TIME by not doing it!**
      - You can use these flags `--no-common --no-internal` to bypass the default behavior which will make a fresh build of menlo common and internal every time before your app is built.

- ##### **Testers**
    - *There maybe a situation where a tester can optimize there build if they know that the package-lock.json in their test branch did not deviate from the master branch's version.*
      - **In that case, you may have a situation where all of your dependencies can possibly be installed only once, and then proceed to use `--no-ci`. But I have not verified if this situation works.**
