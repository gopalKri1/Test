# menlo-internal

Shared React containers and Redux code for Menlo projects internal use only.

it's currently hosting component that is share between apps, but not intend to expose to external 3rd parth like menlo-common intended to do.

to build:

npm ci

npm run build
