# Welcome to menlo-web-service-mqtt

## The Menlo web-service-mqtt (aka vehicle simulator)

The project was created to similuate vehicle signal to the front end (center-stack and cluster) using mqtt

### How To:

1.  Install Node.js: https://nodejs.org
2.  Install Git: https://git-scm.com/ (You may need to follow Ford Git setup instructions: https://pages.github.ford.com/ford/doc/GitHub/)
3.  Open up Git Bash and navigate to your projects folder.
4.  Clone the repository. `git clone https://github.ford.com/Menlo/menlo-web-services-mqtt.git` (This will make a folder called menlo-web-services-mqtt in your projects folder).
5.  Navigate to the menlo-web-services-mqtt folder.
6.  Run: `npm install` (npm is installed alongside Node.js. If the install fails, see the proxy note below.)
7.  Run: `npm start`
8.  Open up a browser and navigate to: 127.0.0.1:7000
9.  Click around.
10. Try editing the source/client/containers/application/Application.jsx file
11. Change the Hello Menlo text
12. Save the file - notice the UI update automatically while retaining the page state.

### Notes:

If your `npm install` step fails, you may have to set up the Ford Proxy so NPM can pull down the required packages.

- Ford Proxy Information: http://www.tcs.ford.com/internetaccess/default.asp?ID=310
- NPM Proxy Configuration: `npm config set proxy http://proxyvipecc.nb.ford.com:83` (Using an Americas proxy address)

### More Important Notes:

- The basic MQTT connection can be configured with query string parameters like so: http://127.0.0.1:7001/menlo-mqtt/?mqttHost=127.0.0.1&mqttPort=7000
- The ALM settings work through a separate MQTT connection that is currently configured in a different way. You can configure the host and port it connects with by passing in environment variables, WS_SERVER_HOST and WS_SERVER_PORT. You can pass them in by altering the package.json npm start:dev script like so: "start:dev": "cross-env WS_SERVER_HOST=127.0.0.1 NODE_CONFIG_DIR=configuration/server NODE_ENV=development node source/server/index.js",
