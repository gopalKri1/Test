# Welcome to menlo-center-stack

## The Menlo Center Stack

The project was created to show what the HMI could look like if it was written for the web.

Here are some of the technology choices used in creating this project with some overly-simplified descriptions:

1.  React - The core technology used in the front-end.
2.  React Router V4 - Manages the application location state.
3.  Redux - Manages the entire application state.
4.  Webpack - Packages up our app and gives us some powerful tools to help manage our assets.
5.  Babel - Lets us write more modern JavaScript code.
6.  CSS-Modules - To keep your CSS local and more modular.
7.  Hot Reloading - To see JavaScript and CSS updates applied instantly to improve workflow.
8.  Express - Mainly used as a file server to pass along asset requests and to keep things sandboxed.

### TODO:

1.  Localization - Not difficult to add, just needs to be done.
2.  Unit Tests, End-to-end Tests, Squish Tests...

### How To:

1.  Install Node.js: https://nodejs.org
2.  Install Git: https://git-scm.com/ (You may need to follow Ford Git setup instructions: https://pages.github.ford.com/ford/doc/GitHub/)
3.  Open up Git Bash and navigate to your projects folder.
4.  Clone the repository. `git clone https://github.ford.com/Menlo/menlo-center-stack.git` (This will make a folder called menlo-center-stack in your projects folder).
5.  Navigate to the menlo-center-stack folder.
6.  Run: `npm install` (npm is installed alongside Node.js. If the install fails, see the proxy note below.)
7.  Run: `npm run dev`
8.  Open up a browser and navigate to: 127.0.0.1:8000
9.  Click around.
10. Try editing the source/client/containers/application/Application.jsx file
11. Change the Hello Menlo text
12. Save the file - notice the UI update automatically while retaining the page state.

### Use with the local simulator

1. Clone and run menlo-web-service
2. Clone and run mosquitto-broker-executable
3. Disconnect the simulator and set the IP as 127.0.0.1 PORT 7000
4. Start center stack and add this URL parameters ?mqttHost=127.0.0.1&mqttPort=7000

### Notes:

If your `npm install` step fails, you may have to set up the Ford Proxy so NPM can pull down the required packages.

- Ford Proxy Information: http://www.tcs.ford.com/internetaccess/default.asp?ID=310
- NPM Proxy Configuration: `npm config set proxy http://proxyvipecc.nb.ford.com:83` (Using an Americas proxy address)

### Unit testing:

currently, unit test is implemented with Jest v22.4.x, Enzyme v3.3.0, with enzyme-adapter-react v16.1.x.

The following documentation will be helpful for writing unit test:

Enzyme:
https://airbnb.ip/enzyme/docs/api

Jest:
https://facebook.github.io/jest/docs/en/api.html

expect Library:  
https://facebook.github.io/jest/docs/en/expect.html

#to run unit test: `npm test`

#to run unit test suite: `npm test:watch`
It will run everytime you have a file change.

#to run unit test coverage: `npm test:coverage`
to view coverage report, open coverage/lcov-report/index.html in a browser

#test example: (this will change when we have more tes cases developed)
source/client/components/AppButton/AppButton.test.js
