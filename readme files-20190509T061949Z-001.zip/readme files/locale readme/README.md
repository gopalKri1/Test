# Welcome to menlo-locale

## The Menlo Locale project
The project was created to provide a way for strings to be defined for both translations & the menlo applications.

### How To:
1.  Navigate to the menlo-core/menlo-locale folder.
2.  Run: `npm ci`
3.  If menlo-core/menlo-locale doesn't contain a `localefiles` folder, run `npm run get-originals`
    -- The `localefiles` folder should now exist & contain various app-named .json files (controls.json, phone.json etc)
4.  Run: `npm run build:watch`. The following should be created in menlo-locale:
    -- A `src/.locale_gen` folder containing app-named .json files (radio.json, media.json etc)
    -- A `dist` folder containing webpack bundle
    IMPORTANT: Do not hand-edit these files.
5.  Make sure to change the stringValues imports in your desired apps & change them to use the objects exported from menlo-locale
    -- For example:
         in menlo-center-stack/source/client/components/SettingsDrawer/controls/ControlsTab.jsx
             change: import {stringValues} from "./locale/locale";
             to: import {control as stringValues} from "menlo-locale";
         in menlo-core/menlo-application-media/src/index.js
             change: import {stringValues} from "./locale/locale";
             to: import {media as stringValues} from "menlo-locale";
5.  Run your desired applications (center-stack, media, phone etc)
6.  If you need to add or amend any strings, do so in the relevant `src/locale/appName.json` file (phone.json, appLink.json etc)
    -- When you save any changes in localefiles, all strings will be updated.
