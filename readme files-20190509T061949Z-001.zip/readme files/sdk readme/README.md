# Menlo SDK v1.0
The idea behind  Menlo SDK is to create an interface between all the Menlo APIs and the applications. **The final goal is to simplify the development experience and seep up the process** in this way developers will be able to focus on more interesting tasks. 🚀

---

The SDK is responsible to initialize and configure the application and center-stack, **MenloApplication** component will start these actions:

1.  Initialize application;
2.  Set the manifest;
3. Create the reducer bundle and combine with application reducers
4. Create the saga bundle and combine with application sagas
5. Start saga and create the redux provider
6.  Request the configuration;
7.  Get the right configuration for development, server and target;
8. Store the configuration;
9. Initialize the SDK client;
	- Initialize MQTT
10.  Subscribe to the initial topic;
11. Add the event listeners for MQTT (onMessage, onClose, onError);
12. Handle the signals checklist and the application state;
13. Parse the topic;
14. Handle the batch update for redux;
15. Create the initial value for the reducers;
16. Create a new store when receiving a new topic;
17. Handle and apply services like theme or locale;
18. Parse the update topic and forward to a watcher action;

In this first version, the SDK provides an easy way to implement communication with MQTT: 

* Send a topic.
* Get the value from the redux.
* Dispatch and watcher action for the update topic.

---

## Getting Started

- Build: npm run build
- Build and watch: npm run build:dev:watch
- Generate files and documentation: npm run generate
- Generate the documentation: documentjs
- Generate data: npm run generate-data
- Extract all chunks: npm run extract-chunks

---

## Menlo Application
Menlo Application is the wrapper component where everything starts. 
It will contain your application or center-stack and provides, redux, the theme, locale, the loading and AppMaximizer.

### Parameters
| Param name | Type | Description       | 
| ------------- |:-------------:| ------- |
| reducers  | object  |  An object with all the application's reducers |
| sagas | array  |  An array with all the application's sagas |
| manifest | object  |  The manifest object with app information |
| stringValues | object  |  The application's strings (locale) |
| children | object  |  The application's content |

> Will add more details about the **manifest** file soon. This feature is not fully implemented yet.

### How to implement in an application
```javascript
import React from "react";
import ReactDOM from "react-dom";
import Application from "./containers/Application/Application";
import reducers from "./reducers";
import {sagas} from "./sagas";
import {manifest} from "./manifest";
import {MenloApplication} from "menlo-sdk";
const render = function() {
  ReactDOM.render(
    <MenloApplication
      reducers={reducers}
      sagas={sagas}
      manifest={manifest}
    >
      <Application />
    </MenloApplication>,
    document.getElementById("application")
  );
};
render();
```
---


### Get App Id
| function name| return | Description     | 
| ------------- |:-------------:| ------- |
| appId() | String | returns the AppId |
| getAppId() | Promise | returns an promise object with the app id. Use that in your saga files |

## How to use MQTT topic in your application
Using MQTT signals with SDK is pretty simple. You don't need to worry about the topic implementation and signals testing will be automated.

Before looking into the code, you need to know that that there are three different types of topic: **Event**, **Value** and **Update**.

### Event Topics
The *event topic* type is something that we usually use to send a message to the vehicle. One use case could be a button that needs to set on and off the air conditioner in the car. 

In this case, you'll need to go in the SDK, identify the topic group (in this case climate), then browse to **actions** and search for "air conditioner".

### Value Topics
The *value topic* type is connected to a value that is retained in the MQTT broker. You can subscribe to a value topic and your client code will receive the retained value immediately and, subsequently, any time that the value changes. 

One use case could be the air conditioner button that needs to change the state from on to off when the car state changes. In order to get the value, we need to subscribe to the right topic. Then the SDK will take care to set the current value on the redux state.
To subscribe to this topic, identify the topic group in the SDK (in this case climate), then browse to **helpers** and search for "air conditioner".
The get value helpers provide an easy way to get the value from the redux state.

### Update Topics
The *update topic* does **NOT** retain a value. That means MQTT will receive a value from the vehicle, then publish a topic and forgot about it immediately after. The main difference with the value type is that when we subscribe to an update topic we'll receive the topic only when MQTT receives it from the vehicle. i.e. there is no value supplied immediately upon subscription.

Let's try to imagine that we have to handle a message from the vehicle about the low tire pressure. In this case, we need to show a popup with a warning.

### How to send Topic and update the component state
This code demonstrates how to send a topic event and get the value from the state using the container/component design pattern. Please notice that we import two methods in the container, one (sendClimateEventAirConditioningButton) returns an action that will be dispatched through the SDK to publish the right topic. The other method (getClimateValueAirConditioningActive) is a helper that gets the state as a parameter and returns the value from the redux state.
```javascript
//Your container
import {
  sendClimateEventAirConditioningButton, 
  getClimateValueAirConditioningActive
} from "menlo-sdk";

class MyContainer extends React.PureComponent {
  render() {
    const {action, value} = this.props;
    return(
      <MyComponent
        action={action}
        value={value}
      />
    );
  }
  const mapStateToProps = function(state) {
    return {
        value: getClimateValueAirConditioningActive(state)
    };
  };
  const mapDispatchToProps = function(dispatch) {
    return bindActionCreators(
      {
        sendClimateEventAirConditioningButton,
      },
      dispatch
    );
  };

  export connect(mapStateToProps, mapDispatchToProps)(MyContainer);
}
 
//Your Component class 
MyComponent extends React.PureComponent {   
    render() {   
        const {action, value} = this.props;    
        return (      
            <div>
                <button
                   isSelected={value}
                   onClick={action}        
                />        
            </div>
        )
    } 
    MyComponent.propTypes = { 
        value: PropTypes.Boolean,  
        action: PropTypes.func
    };
}
```

> ⚠️ *As you can see,  for event and value topics, you no longer need to implement any reducer, action or saga.  Consistency of approach is one of the main value propositions for the SDK.*
* We have a single coding pattern to implement and maintain.  
* We have a single code base in which to make performance optimizations or retrofit changes in the way we bind to lower layers.

With that in mind, please do not implement any other solution or try to send or get a topic in any other way. If you have special need take a look at the SDK road map or contact the SDK team, we'll be happy to help you and find the best solution together.

### How to publish an event topic with a message (v1)
1. Send a simple data type message as a simple argument
```javascript
sendTunerMixedPresetEventChangeActiveBank(2);
```
2. Send Custom data type message as an object
```javascript
const obj = {mainAudioSrcType: 2, templatedAudioSrcType: 0 };
sendAudioEventAudioSrcChanged(obj);
```
Please check menlo-proto to identify the right value to pass as parameter.
> ⚠️ This implementation is an MVP, we'll provide a better solution in the next versions of the SDK

### How to add some logic before publishing a topic
In some cases, you may need to add some logic before publishing a topic.
Before the SDK and Saga this one was a very common implementation:

```javascript
export function setDateTimeHour(hour, minutes) {
  return function(dispatch, getState) {
    let message = new hmi_settings_message_pb.Time_Event_SetTime();
    let state = getState();
    const {clock} = state;
    let year = getYear(clock);
    let month = getMonth(clock);
    let day = getDay(clock);
    let seconds = getSecond(clock);
    message.setDateyear(year);
    message.setDatemonth(month);
    message.setDateday(day);
    message.setTimehour(hour);
    message.setTimemin(minutes);
    message.setTimesec(seconds);
    let serializedMessage = message.serializeBinary();
    dispatch(sendMqttMessage("hmi/time/event/set-time", serializedMessage));
  };
} 
```
This code we can improve may things:
- Actions **must be** a plain object
- Is still using "dispatch"
- Is not using the SDK

Let's see how to do that:
```javascript
//actions file
export const setDateTimeHour = (hour, minutes) => ({
   type: WATCHER_SET_DATE_TIME_HOUR,
   hour: hour,
   minutes: minutes
});

//saga file utility method
function* myFunction({hour, minutes}) {
  try {
    //get clock from the state
    const clock = yield select(state => state.clock);
    yield call(validateAllParams, clock, hour, minutes); // this method returns an error if the params are not defined or null
    const message = yield call(createNewTimeMessage, clock, hour, minutes); //in the v1 of the SDK you need to create an helper utilitiy
    yield put(sendTimeEventSetTime(message)); //impor {sendTimeEventSetTime} from "menlo-sdk"
  } catch (error) {
    yield put(myActionError(error));
  }
}
function* myFunctionWatcher() {
  yield takeLatest(WATCHER_SET_DATE_TIME_HOUR, myFunction);
}

//helpers file
const createNewTimeMessage = (clock, hour, minutes) => {
    try {
       let message = new hmi_settings_message_pb.Time_Event_SetTime();
       let year = getYear(clock);
       let month = getMonth(clock);
       let day = getDay(clock);
       let seconds = getSecond(clock);
       message.setDateyear(year);
       message.setDatemonth(month);
       message.setDateday(day);
       message.setTimehour(hour);
       message.setTimemin(minutes);
       message.setTimesec(seconds);
       return Promise.resolve(message);
    } catch (err) {
    	return Promise.reject(err);
    }
};

```

### How to use an update topic
First of all your client needs to subscribe to the right topic. 
When the SDK receives an update topic, it will parse the message and dispatch a new watcher action.

```javascript
{
	type: "WATCHER_MY_TOPIC_NAME",
	topic: "hmi/chunck-name/update/topic-name",
	message: "parsed message value"
}
```
To implement an update topic, we'll need to capture the action in a saga file hosted in the application. In order to do that, go to the documentation, browse to the right group, and under helpers search for the proper method. 

```javascript
// mySagaFile.js
import {
	watcherAlexaUpdatePositionChanged,
	alexaUpdatePositionChangedError
} from "menlo-sdk";
function* myFunction({message}) {
  try {
    // utility method
    const newValue = yield call(doSomethingWithMessage, message);
    // Save the new value in the application redux ex. showMyPopup = true;
    yield put(myApplicationActionWorkerName(newValue));
  } catch (error) {
    yield put(alexaUpdatePositionChangedError(error));
  }
}
function* myFunctionWatcher() {
  yield takeLatest(watcherAlexaUpdatePositionChanged(), myFunction);
}
//EXPORTED WATCHERS
export default [myFunctionWatcher];
```

> ⚠️ *Please notice two things.* **1.** Use the helper function to get the watcher name **2.** Realize that this will cause a change in application redux state that drives UI, but it is not necessarily going to reflect system state.  Try to make this clear when naming and consuming state properties. Remember that update topics are not persisted in MQTT. In the example above, the update will result in showing a popup in the UI: dismissing the popup could occur when the user clicks a close button in the popup and the close button will likely be bound to an application action that results in application redux state being updated **WITHOUT** any signals being sent through the SDK.  If and when occurs, we will have a redux state property whose value may not match the state of the car.  i.e. this property represents the state of the popup, not the state of the car.

### How to combine update topics and save a temp value
```javascript
var obj = {};
function* eaCouldNotEstablishCall({message}) {
    try {
        obj = obj.eaCouldNotEstablishCall = message;
        obj = obj.time = new Data();
    } catch (error) {
        yield put(showEmergencyAssistError());
    }
}
function* eaCouldNotEstablishCallWatcher() {
    yield takeLatest(
        watcherEaUpdateCouldNotEstablishCall()
    , eaCouldNotEstablishCall);
}
function * eaUpdateAboutToCallEmergencyNumber({message}) {
    const isTime = yield call(checkTime, obj.time, THRESHOLD_TIME);
    if(isTime && obj.eaCouldNotEstablishCall && message) {
        yield put(myAction());
    }
}
function* updateAboutToCallEmergencyNumberWatcher() {
    yield takeLatest(
        watcherEaUpdateAboutToCallEmergencyNumber()
    , eaUpdateAboutToCallEmergencyNumber);
}
```
> ⚠️ This solution is for V1 in the next versions will be a feature to combine multi-value in one object.

### How to generate a watcher action for a value topic
In some **special** cases you may need to add some logic when we receive a value topic from MQTT. Let's say that we what execute a saga function every time the broker published ac-button-value. In this case you can use a feature named "shouldDispatch".
- Go to the UI tool in the SDK:
```
  cd menlo-sdk
  npm run generate-data
  cd menlo-sdk/toolset/signal-groups
  npm install
  npm start
  
  Navigate to -> localhost:3000
```
>
- Find the value topic
- Check on "shouldDispatch"
- Save the data
- Cd to your SDK folder ```npm run generate-data && npm run generate && npm run build```
At this point, the SDK will dispatch a new action watcher every time will receive the value topic. From here you can treat it has a normal update topic.
> ⚠️ This is a very expensive feature please use just if necessary.

### Subscribe to a topic using the manifest
In the application manifest, we can define an array of topics that we want to subscribe to when an application starts. This operation is not recommended for performance reasons - if you want to use it please be sure that you really need it. For more details check the documentation for the application manifest.

### Use the SDK methods
| Name | Params | Description | 
| ------------- |:-------------:| ------- |
| client.subscribeToTopic() | function | This method uses the function to find the topic name and subscribe the client. |
| client.subscribeToTopics() | array of functions | This method is used to subscribe to many topics. |
| client.unsubscribeToTopic() | function | This method uses the function to find the topic name and unsubscribe the client. |
| client.unsubscribeToTopics() | array of functions | This method is used to unsubscribe to many topics. |


--- 

## Application manifest
> ⚠️ This part is not in production yet we're working hard to complete it as soon as possible.

--- 

## Automatic optimistic UI
> ⚠️ This part is not in production yet we're working hard to complete it as soon as possible.
At this stage, we're conducting some performance tests on the car in order to provide the best solution to the developers. 

--- 

## How to use the documentation
- cd to the menlo-sdk folder.
- run npm run generate.
- go to the sdk-documentation folder.
- open the index.html file.
- browse to the group that you're looking for.

---

## Road Map
This is the list of what is completed and the new features that we're working on. 
Please check the Jira associated for more details.

- [x] Create the SDK client
- [x] Create a new MenloApplication
- [x] Improve the parsing method
- [x] Add the redux batch update
- [x] Create the UI tool to add topic information (binding, description...)
- [x] Create a tool to manage the initial value
- [x] Generate all the actions
- [x] Generate the Helpers
- [x] Handle update topics
- [x] Create documentation
- [x] Use the SDK in menlo-center-stack
- [ ] Use the SDK in the radio app [PR](https://github.ford.com/SYNC/menlo-core/pull/769)
- [ ] Use the SDK in the media app 🔥 [SYNC-53343](https://jiramg.ford.com/browse/SYNC-53343) [SYNC-53339](https://jiramg.ford.com/browse/SYNC-53339) [SYNC-53336](https://jiramg.ford.com/browse/SYNC-53336)
- [ ] Use the SDK in the phone app
- [ ] Move notifications to the SDK
- [ ] Remove all the reducers and saga from menlo-common
- [ ] Remove all the reducers and saga from menlo-internal?
- [x] Add the initial value into the documentation
- [ ] Complete the bind information 
- [ ] Create unit tests using a full bench 🔥
- [x] Automate the updating process from menlo proto
- [x] Create a service to bind value changes and watcher actions
	- [x] Add on the UI tool a way to flag "send an action" for value topic
	- [x] Add on the SDK a separate tread to dispach actions for some value (MVP)
- [ ] Create a UI tool to combine more value topic in one object
- [ ] Combine multiple value topics in one object
- [ ] Combine list value topics in one object
- [ ] Move browser API into the SDK
- [x] Add the logic for the initial subscribe
- [ ] Add the logic to add and remove reducers and sagas from the manifest
- [ ] Automatic otimistic UI 🔥
- [ ] Save cached value in the browser local storage
- [ ] Remove redux thunk
- [ ] Add saga to the apps 🔥
- [ ] Implement redux reselect
- [x] Add multi parmams in the event action

--- 

## Questions, issues, requests
What is better than build something together. We want to hear from you, your feedback matters. Even if we'll try to know all about the project architecture and processes, is going to be impossible for us to have a complete picture of the entire system. If you're working on something that is not yet completely optimized or you are not comfortable with the solution that we had proposed, please let us know. We'll do our best to find a solution to simplify your operation.

### SDK team members
- [Enrico](https://github.ford.com/EPIOVESA)
- [Jonathan](https://github.ford.com/JWEATH33)
- [Dante](https://github.ford.com/DXIE6)


### SDK open tickets
[Jira ticket](https://jiramg.ford.com/browse/SYNC-50874?jql=labels%20%3D%20menlo-sdk)

### Webex team
[MenloSDK](https://teams.webex.com/spaces/a929bd50-4fe9-11e9-bf0a-43ad128e3b9d/chat)

### I found a bug or I have an issue
Please create a new ticket and assign it to Enrico, he'll take an action. Please do not use random webex team chat.

### How to debug event topics
- Bind the action to your UI
- Click the button
- Open Mqtt Spy and subscribe to the right event topic
- Check the log

### How to debug value topics
- Make sure that your app is subscribing to the right topic (not necessary on v1)
- Use the helper method and pass the state
- Open the web simulator
- Send the topic
- Check your redux state
- Check the state of the UI

> ⚠️ If the previous steps are completed and you can close the loop in the bench, please check if your signal is already implemented in the HMI_AL or your bench configuration. If that not resolve the issue create a new defect Jira.

--- 

## Links
- Creating a protobuf message by name: https://github.ford.com/SYNC/HMI/blob/bd85479edaccc33a7daa39a90009a5ba93855f5e/HMI_AL/src/MQTTTopicTable.cpp#L102
- Walking the fields of a message: https://github.ford.com/SYNC/HMI/blob/bd85479edaccc33a7daa39a90009a5ba93855f5e/HMI_AL/src/MQTTBufferToProtobufMessageTransformer.cpp#L248

- HMI MQTT Topic Tree: 
https://www.eesewiki.ford.com/display/sync/HMI+MQTT+Topic+Tree#HMIMQTTTopicTree-Domain

--- 

![alt text](https://github.ford.com/SYNC/menlo-core/blob/master/menlo-sdk/public/stack.PNG?raw=true)
