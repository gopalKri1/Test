# menlo-test-ids

## A repo maintaining the automation test team's unique id's across menlo applications

Id's are held in a Javascript Object, and can be pulled inside of any menlo-application to be added to interactable components.

For example if you look at the folder structure you will see folders for center-stack, media, phone, and radio.

Inside of center-stack/settings.js, for example, we export a Javascript object that contains the ids we wish to import into our centerstack code. 

Let's say you wish to import this object into an imaginary file called settingsWidget.jsx in menlo-center-stack

inside settingsWidget.jsx we will include the following code:

```
import {SettingsIds} from "menlo-test-ids";

//you can console log it to see that it pulls in the javscript object needed with the test ids:
console.log(">>>>>>>>>>", SettingsIds);
```

For an in depth example on how to use these id's please visit:
https://www.eesewiki.ford.com/display/analytics/How-To+Add+Test-Id%27s+to+Menlo

##Converting Data to JSON
There is also a script that can be run to pull the seperate Javascript Objects from the files and convert them to monolithic JSON object. Simply run npm start, if you have npm installed, and that should publish the JSON to a file called testids.json